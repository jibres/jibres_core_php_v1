<?php
namespace content_crm\member\home;

class model
{

	public static function post()
	{


	}
}
?>
<?php
namespace content_crm\member\home;


class controller
{
	public static function routing()
	{

	}
}
?>
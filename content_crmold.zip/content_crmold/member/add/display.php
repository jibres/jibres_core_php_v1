
<form method="post" enctype="multipart/form-data" autocomplete="off">
<div class="f justify-center">
  <div class="c4 s12">
    <div class="cbox">

        <label for="mobile"><?php echo T_("Mobile"); ?></label>
		<div class="input">
		  <input type="tel" name="mobile" id="mobile" placeholder='<?php echo T_("Like 09120123456"); ?>'  maxlength='30'>
		</div>

        <button class="btn primary block mT20"><?php echo T_("Add"); ?></button>
    </div>
  </div>
</div>
</form>


<?php
namespace content_crm\member\ticket;


class model
{

	public static function post()
	{


	}
}
?>

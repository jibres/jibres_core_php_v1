

<?php require_once(root. 'content_crm/member/pageSteps.php'); ?>


	<div class="f">

	 <div class="cauto s12 pA5">
		<?php require_once(root. 'content_crm/member/psidebar.php'); ?>

	 </div>

	 <div class="c s12 pA5">



	 </div>

	</div>


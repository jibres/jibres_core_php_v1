
<?php
require_once (\dash\data::supportAdmin());
?>
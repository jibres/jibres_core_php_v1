<?php
namespace content_my\ipg\profile;


class controller
{
	public static function routing()
	{

	}
}
?>
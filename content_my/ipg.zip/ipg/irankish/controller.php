<?php
namespace content_my\ipg\irankish;


class controller
{
	public static function routing()
	{
		\lib\irankish\run::run();
	}
}
?>
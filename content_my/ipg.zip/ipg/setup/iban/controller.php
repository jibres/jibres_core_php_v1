<?php
namespace content_my\ipg\setup\profile;


class controller
{
	public static function routing()
	{

	}
}
?>
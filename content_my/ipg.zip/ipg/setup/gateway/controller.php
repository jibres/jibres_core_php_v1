<?php
namespace content_my\ipg\setup\gateway;


class controller
{
	public static function routing()
	{

	}
}
?>
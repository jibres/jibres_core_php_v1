<?php
namespace content_my\ipg\gateway;


class model
{
	public static function post()
	{
		$post =
		[
			'title'      => \dash\request::post('title'),
			'websiteurl' => \dash\request::post('websiteurl'),
			'email'      => \dash\request::post('email'),
			'phone'      => \dash\request::post('phone'),
		];

		\lib\app\shaparak\shop\set::first_gateway($post);

		if(\dash\engine\process::status())
		{
			\dash\redirect::pwd();
		}
	}
}
?>
<?php
namespace content_my\ipg\gateway;


class controller
{
	public static function routing()
	{

	}
}
?>
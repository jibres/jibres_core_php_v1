<?php
class sql_lib{
	public $tables = array();
	private $blackList = array("index", "foreign", "unique");
	public static $connection = false;

	/**
	 * @param [object] $maker object of sql maker for make string query
	 */
	public function __construct($maker){
		if(class_exists("sql_cls")) {
			$c = new sql_cls($maker);
		}
		$this->maker = $maker;
		$this->tables = (object) array();	
		$this->loadTable();
	}

	/**
	 * [__call description]
	 * @param  [string] $name [virtual function name]
	 * @param  [array] $args [arguments of virtual function]
	 * @return [type]       [description]
	 */
	public function __call($name, $args){
		// var_dump($this->maker->groupby);
		$syntax = "{$name}Caller";
		$string = $this->$syntax();
		if(preg_match("/^(insert|delete|update|select)$/", $name)){
			$groupby_ = $this->maker->groupby;
			$string .= ($this->maker->groupby) ? " GROUP BY `$groupby_`" : '';
			preg_match("/^([^\s]+)(\s(ASC|DESC))?$/", $this->maker->order, $order);
			if(count($order) == 4){
				$sort = $order[3];
				$orderField = $order[1];
				$string .= ($this->maker->order) ? " ORDER BY `$orderField` $sort" : '';
			}
			$string .= (count($this->maker->limit) > 0) ? " LIMIT ". join($this->maker->limit, ', ') : '';
			// echo "\n<pre>\n";
			// print_r($string);
			// echo "\n</pre>\n";
			$connection = new dbconnection_lib;
			$result = $connection->query($string);
			return $result;
		}else{
			return $string;
		}
	}

	/**
	 * function for make select query
	 * @return [string] string of select query
	 */
	public function selectCaller(){
		$string = "SELECT ";
		$fields = array();
		$tables = array();
		$this->oField($this->maker, $fields);
		array_push($tables, $this->maker->table);
		foreach ($this->maker->join as $key => $value) {
			array_push($tables, $value->table);
			$this->oField($value, $fields);
		}
		$tablse = array($this->maker->table);
		$string .= join($fields, ", ");
		$string .= " FROM ". $this->maker->table;
		$string .= $this->join();
		if(count($this->maker->conditions) > 0){
			$string .= " WHERE".$this->condition($this->maker);
		}
		return $string;
	}


	public function insertCaller(){
		$string = "INSERT INTO ";
		$string .= $this->maker->table;
		$keys = array_keys($this->maker->set);
		foreach ($keys as $key => $value) {
			$keys[$key] = $this->oString($this->maker->table, $value);
		}

		$values = array_values($this->maker->set);
		foreach ($values as $key => $value) {
			$values[$key] = $this->oString($this->maker->table, $keys[$key] ,$value);
		}

		$string .= " (".join($keys, ", ").")";
		$string .= " VALUES (".join($values, ", ").")";
		return $string;
	}

	public function updateCaller(){
		$string = "UPDATE ";
		$string .= $this->maker->table;
		$keys = array_keys($this->maker->set);
		foreach ($keys as $key => $value) {
			$keys[$key] = $this->oString($this->maker->table, $value);
		}

		$values = array_values($this->maker->set);
		foreach ($values as $key => $value) {
			$values[$key] = $keys[$key]. " = ".$this->oString($this->maker->table, $keys[$key] ,$value);
		}
		$string .= " SET ". join($values, ", ");
		if(count($this->maker->conditions) > 0){
			$string .= " WHERE".$this->condition($this->maker);
		}
		return $string;
	}

	public function deleteCaller(){
		$string = "DELETE FROM ";
		$string .= $this->maker->table;
		$string .= " WHERE".$this->condition($this->maker);
		return $string;
	}

	public function join(){
		$string = "";
		foreach ($this->maker->join as $key => $value) {
			$string .= " INNER JOIN ".$value->table." ON";
			$string .= $this->condition($value);
		}
		return $string;
	}

	/**
	 * [condition description]
	 * @param  [type] $maker [description]
	 * @return [type]        [description]
	 */
	public function condition($maker){
		// var_dump($maker->conditions);
		$string = "";
		foreach ($maker->conditions as $key => $value) {
			if(isset($value[0])){
				foreach ($value as $ckey => $cvalue) {
					if($ckey == 0){
						$string .= $key != 0 ? " ".strtoupper($cvalue["condition"])."(" : "(";
					}else{
						$string .= " ".strtoupper($cvalue["condition"])." ";
					}
					$string .= $this->conditionString($cvalue, $maker->table);
				}
				$string .= ")";
				/**
				 * 
				 */
			}else{
				$string .= $key != 0 ? " ".strtoupper($value["condition"])." " : " ";
				$string .= $this->conditionString($value, $maker->table);
			}
		}
		return $string;
	}
	/**
	 * [conditionString description]
	 * @param  [type] $condition [description]
	 * @param  [type] $table     [description]
	 * @return [type]            [description]
	 */
	public function conditionString($condition, $table){
		$string = "";
		if(preg_match("/^#(.*)$/", $condition['field'], $field)){
			if(strtolower($condition['operator']) == "like"){
				$op = "";
				if(preg_match("/^%(.*)$/", $condition['value'], $v)){
					$condition['value'] = $v[1];
					$op .= "0";
				}
				if(preg_match("/^(.*)%$/", $condition['value'], $v)){
					$condition['value'] = $v[1];
					$op .= "1";
				}
				$val = $this->oString($table, $field[1], $condition['value'], false);
				if(preg_match("/0/", $op)){
					if(preg_match("/^'/", $val)){
						$val = preg_replace("/^'/", "'%", $val);
					}else{
						$val = "'%$val";
					}
				}
				if(preg_match("/1/", $op)){
					if(preg_match("/'$/", $val)){
						$val = preg_replace("/'$/", "%'", $val);
					}else{
						$val = "$val%'";
					}
				}
			}else{
				$val = $this->oString($table, $field[1], $condition['value']);
			}
			
			$string .= $this->oString($table, $field[1])." {$condition['operator']} ". $val;
		}else{
			$string .= "$condition[field] {$condition['operator']} $condition[value]";
		}
		return $string;
	}

	/**
	 * set optiomize of select fields
	 * @param  [object] $maker   [sql maker object]
	 * @param  [array] $aFields [array of fields]
	 */
	public function oField($maker, &$aFields){
		$table = $maker->table;
		$fields = is_array($maker->fields) ? $maker->fields : array($maker->fields);
		if(!$fields[0] || $fields[0] == "*"){
			array_push($aFields, $this->oString($table, "*"));
		}else{
			foreach ($fields as $key => $value) {
				array_push($aFields, $this->oString($table, $value));
			}
		}
	}

	/**
	 * optimize sql table, fields and value
	 * @param  [string] $table [set table name]
	 * @param  [string] $field [set field name]
	 * @param  [string] $value [set value]
	 * @return [string]        [optimize of string]
	 * @example
	 * 	oSting(users)			return #users#
	 * 	oSting(users, id)		return #users.id#
	 * 	oSting(users, id, 150)	return #users.id 150#
	 */
	public function oString($table, $field = null, $value = null, $checkCondition = true){
		if($value){
			$cInt = false;
			if(preg_match("/^#(.*)$/", $value, $v)){
				$value = $v[1];
				$cInt = true;
			}else{
				if(isset($this->tables->$table->$field)){
					$type = $this->tables->$table->$field->type;
					$int = array("int","tinyint", "smalint");
					preg_match("/^([^@]*)@/", $type, $tp);
					if(preg_grep("/^".$tp[1]."$/", $int)){
						$cInt = true;
					}
				}
				if(isset($this->tables->$table->$field->closure) && $checkCondition){
					$table = $this->tables->$table->$field->closure;
					$value = preg_replace("/^\\\#/", "#", $value);
					$v = new validator_lib(array($field, $value), $table->validate, 'form');
					$value = $v->compile();
				}
				$value = htmlentities($value, ENT_QUOTES | ENT_HTML5, "UTF-8");
			}
			$optimize = $cInt ? "$value" : "'$value'";
		}else{
			$optimize = "$table";
			$optimize .= $field ? ".$field" : "";
		}
		return $optimize;

	}

	public function validate($fields){
		$array = array();
		$tables = $this->tables[$this->table];
		foreach ($fields as $key => $value) {
			if(isset($tables->{$key}->closure)){
				$closure = $tables->{$key}->closure;
				$v = new validator_lib(array($key, $value), $closure->validate, 'form');
				$value = $v->compile();
			}
			$array[$key] = htmlentities($value, ENT_QUOTES | ENT_HTML5, "UTF-8");
		}
		return $array;
	}

	/**
	 * load ORM tables on this class
	 * change private $tables as array with $table index
	 */
	public function loadTable(){
		$tName = array($this->maker->table);
		foreach ($this->maker->join as $key => $value) {
			array_push($tName, $value->table);
		}
		foreach ($tName as $key => $value) {
			$this->saveTable($value);
		}
	}

	public function getForms($index = 0){
		$tab = $this->maker->table;
		$table = $this->tables->$tab;
		return $table;
	}

	public function saveTable($name){
		$sName = "\\sql\\{$name}";
		$tables = new $sName;

		foreach ($tables as $key => $value) {
			if(!preg_grep("/^$key$/", $this->blackList)){
				$keys = array_keys($value);
				$values = array_values($value);
				$array = array();
				foreach ($keys as $k => $v) {
					if(is_int($v)){
						$keys[$k] = $values[$k];
						$values[$k] = true;
					}
				}
				if(method_exists($tables, $key)){
					$options = new dbTableOptions_lib;
					$func = new ReflectionMethod("\\sql\\{$name}", $key);
					$cName = "\\sql\\{$name}";
					$Closure = $func->getClosure(new $cName());
					$options->$key = \Closure::bind($Closure, $options);
					$options->table = $tables;
					$options->tableName = $tables;
					$options->fieldName = $key;
					$values[] = $options;
					$keys[] = 'closure';
				}
				$array = array_combine($keys, $values);
				$tables->$key = (object) $array;
			}
		}
		foreach ($tables as $key => $value) {
			if(method_exists($tables, $key)){
				if(isset($tables->{$key}->closure)){
					$closure = $tables->{$key}->closure;
					call_user_func($closure->$key);
				}
			}
		}
		$this->tables->$name = $tables;
	}
}
?>
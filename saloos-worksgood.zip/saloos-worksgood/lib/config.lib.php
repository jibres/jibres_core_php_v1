<?php
class config_lib{
	static $get, $allurl, $URL, $url, $method, $class, $mod, $notget, $surl, $aurl, $child = false, $sClass, $sMethod, $sChild, $subdomain, $aSubdomain;

	static function config(){
		self::get();
		self::url();
		self::child();
		self::method();
		self::cls();
		self::surl();
		self::mod();
		$sClass = false;
		$sMethod = false;
		$sChild = false;
	}

	static function get(){
		$domain = $_SERVER['HTTP_HOST'];
		if(defined("MAIN_DOMAIN")){
			$domain = preg_replace("/(www\.)?".MAIN_DOMAIN."$/", "", $domain);
			if($domain !=""){
				$domain = preg_replace("/\.$/", "", $domain);
				self::$aSubdomain = preg_split("[\.]", $domain, -1, PREG_SPLIT_NO_EMPTY);
				self::$subdomain = $domain;
			}
		}
		$host = 'http://'.$_SERVER['HTTP_HOST'];
		$path = preg_replace("/^\./","",PATH);
		$xurl = preg_replace("#^$host#", '', $_SERVER['REQUEST_URI']);
		$xurl = preg_replace("#^$path#", '', $xurl);
		$xurl = urldecode($xurl);
		preg_match("/^([^?]*)(\?.*)?$/", $xurl, $url);
		self::$allurl = preg_split("[\/]", preg_replace("/^\/|\/$/", '', $url[1]));
		self::$URL = join(self::$allurl, '/');
		if(preg_grep("/^$/", self::$allurl) && count(self::$allurl) > 1){
			page_lib::page("empty path");
		}
		self::$get = (isset($url[2]))? preg_replace("/^\?$/", '', $url[2]) : '';
	}

	static function url(){
		if(count(self::$allurl) > 3){
			$urls = array_slice(self::$allurl, 3);
			self::$url = join($urls,'/');
			self::$allurl = array_slice(self::$allurl, 0,3);
		}
	}

	static function child(){
		if(count(self::$allurl) == 3){
			self::$child = self::$allurl[2];
			if(preg_match("[=]", self::$allurl[2])){
				self::changeChild();
			}
			self::$allurl = array_slice(self::$allurl, 0, 2);
		}else{
			self::$child = '';
		}
	}

	static function method(){
		if(count(self::$allurl) == 2){
			if(self::$allurl[1] == 'home' && self::$url =='' && self::$child == ''){
				page_lib::page("method::home");
			}
			self::$method = self::$allurl[1];
			if(preg_match("[=]", self::$allurl[1])){
				self::changeChild();
				self::changeMethod();
			}
			self::$allurl = array_slice(self::$allurl, 0, 1);
		}else{
			self::$method = 'home';
		}
	}

	static function cls(){
		if(count(self::$allurl) == 1){
			if(self::$allurl[0] == 'home' && self::$method == 'home'){
				page_lib::page("class::home");
			}
			self::$class = self::$allurl[0];

			if(preg_match("[=]", self::$allurl[0])){
				self::changeChild();
				self::changeMethod();
				self::changeClass();
			}
			self::$allurl = null;
		}else{
			self::$class = 'home';
		}
	}

	static function surl(){
		$s = preg_split("[\/]", self::$url);
		self::$aurl = (self::$url !='')? $s : array();
		$s2 = array();
		foreach ($s as $key => $value) {
			preg_match("/^([^=]*)(=(.*))?$/", $value, $ss);
			$s2[$ss[1]] = (isset($ss[3]))? $ss[3] : null;
		}
		self::$surl = (self::$url !='')? $s2 : array();
	}

	static function mod(){
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			self::$mod = 'model';
		}else if($_SERVER['REQUEST_METHOD'] == 'GET'){
			self::$mod = 'view';
		}else{
			page_lib::access("method is false");
		}
	}

	static function makeurl($p){
		if($p != 'home'){
			self::$url = (self::$url !='')? $p.'/'.self::$url : $p;
			self::surl();
		}
	}

	static function changeChild($str = ''){
		if(self::$child != ''){
			self::$url = (self::$url !='')? self::$child.'/'.self::$url : self::$child;
		}
		self::$sChild = self::$child;
		self::$child = $str;
		self::surl();
	}

	static function changeMethod($str = 'home'){
		if(self::$method != 'home'){
			self::$url = (self::$url !='')? self::$method.'/'.self::$url : self::$method;
		}
		self::$sMethod = self::$method;
		self::$method = $str;
		self::surl();
	}

	static function changeClass($str = 'home'){
		if(self::$class != 'home'){
			self::$url = (self::$url !='')? self::$class.'/'.self::$url : self::$class;
		}
		self::$sClass = self::$class;
		self::$class = $str;
		self::surl();
	}
}

class post{
	public static function __callStatic($name, $args){
		return isset($_POST[$name])? $_POST[$name] : false;
	}
}
class get{
	public static function __callStatic($name, $args){
		return isset($_GET[$name])? $_GET[$name] : false;
	}
}
?>
<?php
class dbTableOptions_lib{
	public $validate = null;
	public $form = null;
	public function validate(){
		if(!$this->validate){
			$this->validate = new validateMaker_lib(func_get_args());
		}
		return $this->validate;
	}

	public function form($type = false){
		$formL = new forms_lib();
		$form = $formL->make($type);
		$this->form = $form;
		$table = $this->table;
		if(isset($table->{$this->fieldName}->label)){
			$this->form->label($table->{$this->fieldName}->label);
		}
		if(!$this->validate){
			if(!$form->validate){
				$form->validate();
			}
			$this->validate = $form->validate;
			
		}
		return $form;
	}

	public function setChild($x = false){
		$args = func_get_args();
		$fn = false;
		if(isset($args[0])){
			$fn = isset($args[1]) ? $args[1] : $args[0];
			$fn = (get_class($fn) != "Closure") ? false : $fn;
		}
		$table = $this->table;
		$child = $table->{$this->fieldName}->type;
		$opt = $this->splitor($child);
		$form = $this->form;
		if($opt['type'] == 'enum'){
			foreach ($opt['value'] as $key => $value) {
				$childs = $form->child()->value($value)->label($value)->id($value);
				if($opt['default'] == $value){
					$childs->selected("selected");
				}
			}
		}elseif(isset($table->foreign[$this->fieldName])){
			$field = $table->foreign[$this->fieldName];
			$options = $this->splitor($field);
			if(isset($args[0]) && is_string($args[0])){
				$default = $args[0];
			}else{
				$default = $options['default'] ? $options['default'] : $options['value'];
			}

			$order = "order".ucfirst($default);
			$sql = new sqlMaker_lib();
			$oType = $options['type'];
			$query = $sql::$oType()
			->$order();
			if(is_object($fn)) call_user_func_array($fn, array($query));
			$query = $query->select();
			foreach ($query->allAssoc() as $key => $value) {
				$this->form->child()->value($value[$options['value']])->label($value[$default])->id("list_child_".$value[$options['value']]);
			}
		}
	}


	private function splitor($string){
		preg_match("/^(.*)@([^\!]*)(\!(.*))?$/", $string, $split);
		if($split[1] == 'enum'){
			$value = preg_split("/\s?,\s?/", $split[2]);
		}else{
			$value = $split[2];
		}
		return array("type"=> $split[1], "value" => $value, "default" => isset($split[4]) && !empty($split[4])? $split[4] : false);
	}
}
<?php
class autoload{
	public $classcode = 1200;
	static function hendel($name, $ret = false){
		if(preg_match("/^sql\\\(.*)$/", $name, $xName)){
			$filename = sql.$xName[1].'.sql.php';
			if(file_exists($filename)){
				require_once ($filename);
			}else{
				page_lib::page("table $xName[1] not found");
			}
		}
		$spn = preg_split("[_]", $name);
		$type = $spn[count($spn) -1];
		$name = array_slice($spn, 0, count($spn)-1);
		if(preg_match("/^(model|view|controller|forms|query)$/", $type)){
			if(count($name) == 0){
				$file = join($name,'/');
				$filename = content.config_lib::$class;
				$filename .= '/'.config_lib::$method;
				$filename .= (config_lib::$child) ? '/'.config_lib::$child : '';
			}else{
				$filename = content.'main';
			}
			$filename .= '/'.(($type == 'forms')? 'view' : $type).'.php';
			if(file_exists($filename)){
				if($ret){
					return true;
				}else{
					require_once $filename;
				}
			}else{
				if($ret){
					return false;
				}else{
					page_lib::page(join($spn, '::'));
				}
			}
		}else if(preg_match("/^(lib|cls)$/",$type)){
			if($type == 'lib'){
				$path = lib;
			}else{
				$path = cls;
			}
			$filename = $path.join($name,'/').".$type.php";
			if(file_exists($filename)){
				if($ret){
					return true;
				}else{
					require_once $filename;
				}
			}else{
				$name = join($spn,'::');
				if($ret){
					return false;
				}else{
					page_lib::core(join($spn,'::'));
				}
			}
		}
	}

	static function check($filename){
		return self::hendel($filename, true);

	}
}
spl_autoload_register("autoload::hendel");
?>


<a class="btn hauto block fs20 mTB50" href="<?php echo \dash\url::here(); ?>" data-direct>Home</a>
<a class="btn hauto block fs20 mTB50" href="<?php echo \dash\url::this(); ?>/request" data-direct>Request log</a>
<a class="btn hauto block fs20 mTB50" href="<?php echo \dash\url::this(); ?>/check" data-direct>Check log</a>




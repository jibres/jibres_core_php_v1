<div class="f mTB20">
  <div class="c2 mLR10">
    <a href="<?php echo \dash\url::this(); ?>" data-direct class="btn primary block">Back</a>
  </div>

  <div class="c2 mLR10">
    <a href="<?php echo \dash\url::this(); ?>/check" data-direct class="btn primary block">Check log</a>
  </div>

  <div class="c2 mLR10">
    <a href="<?php echo \dash\url::this(); ?>/request" data-direct class="btn primary block">Request log</a>
  </div>

</div>
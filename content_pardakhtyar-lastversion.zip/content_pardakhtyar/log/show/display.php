<samp>
<?php print_r(\dash\data::dataRow()); ?>
</samp>
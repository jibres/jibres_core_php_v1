
<?php function IfirstNameFa() {?>
<label for="i_firstNameFa">firstNameFa <span class="mLa10">نام به فارسی</span></label>
<div class="input">
  <input type="text" name="firstNameFa" id="i_firstNameFa"  value="<?php echo \dash\data::dataRowCustomer_firstNameFa(); ?>"  maxlength='150' minlength="1" >
</div>
<?php } //endfunction ?>



<?php function IlastNameFa() {?>
<label for="i_lastNameFa">lastNameFa <span class="mLa10">نام خانوادگی به فارسی</span></label>
<div class="input">
	<input type="text" name="lastNameFa" id="i_lastNameFa" value="<?php echo \dash\data::dataRowCustomer_lastNameFa(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IfatherNameFa() {?>
<label for="i_fatherNameFa">fatherNameFa <span class="mLa10">نام پدر به فارسی</span></label>
<div class="input">
	<input type="text" name="fatherNameFa" id="i_fatherNameFa" value="<?php echo \dash\data::dataRowCustomer_fatherNameFa(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IfirstNameEn() {?>
<label for="i_firstNameEn">firstNameEn <span class="mLa10">نام به انگلیسی</span></label>
<div class="input">
	<input type="text" name="firstNameEn" id="i_firstNameEn" value="<?php echo \dash\data::dataRowCustomer_firstNameEn(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IlastNameEn() {?>
<label for="i_lastNameEn">lastNameEn <span class="mLa10">نام خانوادگی به انگلیسی</span></label>
<div class="input">
	<input type="text" name="lastNameEn" id="i_lastNameEn" value="<?php echo \dash\data::dataRowCustomer_lastNameEn(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IfatherNameEn() {?>
<label for="i_fatherNameEn">fatherNameEn <span class="mLa10">نام پدر به انگلیسی</span></label>
<div class="input">
	<input type="text" name="fatherNameEn" id="i_fatherNameEn" value="<?php echo \dash\data::dataRowCustomer_fatherNameEn(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IregisterNumber() {?>
<label for="i_registerNumber">registerNumber <span class="mLa10">شماره ثبت شرکت</span></label>
<div class="input">
	<input type="text" name="registerNumber" id="i_registerNumber" value="<?php echo \dash\data::dataRowCustomer_registerNumber(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IcomNameFa() {?>
<label for="i_comNameFa">comNameFa <span class="mLa10">نام شرکت به فارسی</span></label>
<div class="input">
	<input type="text" name="comNameFa" id="i_comNameFa" value="<?php echo \dash\data::dataRowCustomer_comNameFa(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IcomNameEn() {?>
<label for="i_comNameEn">comNameEn <span class="mLa10">نام شرکت به انگلیسی</span></label>
<div class="input">
	<input type="text" name="comNameEn" id="i_comNameEn" value="<?php echo \dash\data::dataRowCustomer_comNameEn(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IbirthCrtfctNumber() {?>
<label for="i_birthCrtfctNumber">birthCrtfctNumber <span class="mLa10">شماره شناسنامه</span></label>
<div class="input">
	<input type="text" name="birthCrtfctNumber" id="i_birthCrtfctNumber" value="<?php echo \dash\data::dataRowCustomer_birthCrtfctNumber(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IcommercialCode() {?>
<label for="i_commercialCode">commercialCode <span class="mLa10">کد اقتصادی</span></label>
<div class="input">
	<input type="text" name="commercialCode" id="i_commercialCode" value="<?php echo \dash\data::dataRowCustomer_commercialCode(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IforeignPervasiveCode() {?>
<label for="i_foreignPervasiveCode">foreignPervasiveCode <span class="mLa10">شناسه فراگیر اتباع خارجی</span></label>
<div class="input">
	<input type="text" name="foreignPervasiveCode" id="i_foreignPervasiveCode" value="<?php echo \dash\data::dataRowCustomer_foreignPervasiveCode(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IpassportNumber() {?>
<label for="i_passportNumber">passportNumber <span class="mLa10">شماره گذرنامه</span></label>
<div class="input">
	<input type="text" name="passportNumber" id="i_passportNumber" value="<?php echo \dash\data::dataRowCustomer_passportNumber(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IDescription() {?>
<label for="i_Description">Description <span class="mLa10">توضیحات</span></label>
<div class="input">
	<input type="text" name="Description" id="i_Description" value="<?php echo \dash\data::dataRowCustomer_Description(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function ItelephoneNumber() {?>
<label for="i_telephoneNumber">telephoneNumber <span class="mLa10">شماره تلفن</span></label>
<div class="input">
	<input type="text" name="telephoneNumber" id="i_telephoneNumber" value="<?php echo \dash\data::dataRowCustomer_telephoneNumber(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IemailAddress() {?>
<label for="i_emailAddress">emailAddress <span class="mLa10">ایمیل</span></label>
<div class="input">
	<input type="text" name="emailAddress" id="i_emailAddress" value="<?php echo \dash\data::dataRowCustomer_emailAddress(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IwebSite() {?>
<label for="i_webSite">webSite <span class="mLa10">وبسایت</span></label>
<div class="input">
	<input type="text" name="webSite" id="i_webSite" value="<?php echo \dash\data::dataRowCustomer_webSite(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function Ifax() {?>
<label for="i_fax">fax <span class="mLa10">فکس</span></label>
<div class="input">
	<input type="text" name="fax" id="i_fax" value="<?php echo \dash\data::dataRowCustomer_fax(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function Igender() {?>
<label for="i_gender">gender <span class="mLa10">جنسیت</span></label>
<select name="gender" class="ui dropdown select">
  <option value=""><i><?php echo T_("Please select one item"); ?></i></option>
  <option value="0" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_gender() == '0') {echo 'selected';} ?>>Female - زن</option>
  <option value="1" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_gender() == '1') {echo 'selected';} ?>>Male - مرد</option>
</select>

<?php } //endfunction ?>


<?php function ImerchantType() {?>
<label for="i_merchantType">merchantType <span class="mLa10">نوع متقاضی</span></label>
<select name="merchantType" class="ui dropdown select">
  <option value=""><i><?php echo T_("Please select one item"); ?></i></option>
  <option value="0" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_merchantType() == '0') {echo 'selected';} ?>>Real - حقیقی</option>
  <option value="1" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_merchantType() == '1') {echo 'selected';} ?>>Legal - حقوقی</option>
</select>

<?php } //endfunction ?>


<?php function IresidencyType() {?>
<label for="i_residencyType">residencyType <span class="mLa10">ملیت متقاضی</span></label>
<select name="residencyType" class="ui dropdown select">
  <option value=""><i><?php echo T_("Please select one item"); ?></i></option>
  <option value="0" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_residencyType() == '0') {echo 'selected';} ?>>Iranian - ایرانی</option>
  <option value="1" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_residencyType() == '1') {echo 'selected';} ?>>Non-iranian - خارجی</option>
</select>

<?php } //endfunction ?>


<?php function IvitalStatus() {?>
<label for="i_vitalStatus">vitalStatus <span class="mLa10">وضعیت حیات</span></label>
<select name="vitalStatus" class="ui dropdown select">
  <option value=""><i><?php echo T_("Please select one item"); ?></i></option>
  <option value="0" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_vitalStatus() == '0') {echo 'selected';} ?>>Live - در قید حیات</option>
  <option value="1" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_vitalStatus() == '1') {echo 'selected';} ?>>Dead - فوت شده</option>
</select>

<?php } //endfunction ?>


<?php function IbirthCrtfctSeriesLetter() {?>
<label for="i_birthCrtfctSeriesLetter">birthCrtfctSeriesLetter <span class="mLa10">بخش حرفی سری شناسنامه</span></label>
<select name="birthCrtfctSeriesLetter" class="ui dropdown select">
  <option value=" "><i><?php echo T_("Please select one item"); ?></i></option>
  <option value="0" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == '0' ) {echo 'selected';} ?>>الف</option>
  <option value="1" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 1 ) {echo 'selected';} ?>>ب</option>
  <option value="2" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 2 ) {echo 'selected';} ?>>ل</option>
  <option value="3" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 3 ) {echo 'selected';} ?>>د</option>
  <option value="4" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 4 ) {echo 'selected';} ?>>ر</option>
  <option value="5" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 5 ) {echo 'selected';} ?>>۱</option>
  <option value="6" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 6 ) {echo 'selected';} ?>>۳</option>
  <option value="7" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 7 ) {echo 'selected';} ?>>۳</option>
  <option value="8" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 8 ) {echo 'selected';} ?>>۴</option>
  <option value="9" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 9 ) {echo 'selected';} ?>>۹</option>
  <option value="10" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 10 ) {echo 'selected';} ?>>۱۰</option>
  <option value="11" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 11 ) {echo 'selected';} ?>>۱۱</option>
  <option value="12" <?php if(\dash\data::dataRowCustomer() && \dash\data::dataRowCustomer_birthCrtfctSeriesLetter() == 12 ) {echo 'selected';} ?>>ش</option>

</select>

<?php } //endfunction ?>


<?php function IbirthCrtfctSeriesNumber() {?>
<label for="i_birthCrtfctSeriesNumber">birthCrtfctSeriesNumber <span class="mLa10">بخش عددی سری شناسنامه</span></label>
<div class="input">
	<input type="text" name="birthCrtfctSeriesNumber" id="i_birthCrtfctSeriesNumber" value="<?php echo \dash\data::dataRowCustomer_birthCrtfctSeriesNumber(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IbirthDate() {?>
<label for="i_birthDate">birthDate <span class="mLa10">تاریخ تولد</span></label>
<div class="input">
	<input type="text" name="birthDate" id="i_birthDate" value="<?php echo \dash\data::dataRowCustomer_birthDate(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IregisterDate() {?>
<label for="i_registerDate">registerDate <span class="mLa10">تاریخ ثبت متقاضی حقوقی</span></label>
<div class="input">
	<input type="text" name="registerDate" id="i_registerDate" value="<?php echo \dash\data::dataRowCustomer_registerDate(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IpassportExpireDate() {?>
<label for="i_passportExpireDate">passportExpireDate <span class="mLa10">تاریخ انقضای گذرنامه</span></label>
<div class="input">
	<input type="text" name="passportExpireDate" id="i_passportExpireDate" value="<?php echo \dash\data::dataRowCustomer_passportExpireDate(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function InationalCode() {?>
<label for="i_nationalCode">nationalCode <span class="mLa10">کد ملی</span></label>
<div class="input">
	<input type="text" name="nationalCode" id="i_nationalCode" value="<?php echo \dash\data::dataRowCustomer_nationalCode(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IbirthCrtfctSerial() {?>
<label for="i_birthCrtfctSerial">birthCrtfctSerial <span class="mLa10">سریال شناسنامه</span></label>
<div class="input">
	<input type="text" name="birthCrtfctSerial" id="i_birthCrtfctSerial" value="<?php echo \dash\data::dataRowCustomer_birthCrtfctSerial(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function InationalLegalCode() {?>
<label for="i_nationalLegalCode">nationalLegalCode <span class="mLa10">شناسه ملی اشخاص حقوقی</span></label>
<div class="input">
	<input type="text" name="nationalLegalCode" id="i_nationalLegalCode" value="<?php echo \dash\data::dataRowCustomer_nationalLegalCode(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IcountryCode() {?>
<label for="i_countryCode">countryCode <span class="mLa10">کد کشور</span></label>
<div class="input">
	<input type="text" name="countryCode" id="i_countryCode" value="<?php echo \dash\data::dataRowCustomer_countryCode(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


<?php function IcellPhoneNumber() {?>
<label for="i_cellPhoneNumber">cellPhoneNumber <span class="mLa10">شماره تلفن همراه</span></label>
<div class="input">
	<input type="text" name="cellPhoneNumber" id="i_cellPhoneNumber" value="<?php echo \dash\data::dataRowCustomer_cellPhoneNumber(); ?>" maxlength="150" minlength="1">
</div>
<?php } //endfunction ?>


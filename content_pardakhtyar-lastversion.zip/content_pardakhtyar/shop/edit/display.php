<?php require_once(root. 'content_pardakhtyar/shop/layout.php'); ?>


   <form method="post"  autocomplete="off">
    <div class="cbox">
    <?php ADDEDITFORM_shop(); ?>
    <div class="txtRa">
      <button class="btn success"><?php echo T_("Update"); ?></button>
    </div>

    </div>
   </form>

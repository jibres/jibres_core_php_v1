<h2 class="f" data-kerkere='#user-login-detail' data-kerkere-icon='open'>
  <span class="cauto pRa10"><span class="badge primary">POST</span></span>
  <span class="c"><?php echo T_("Login user"); ?></span>
</h2>
<div id="user-login-detail">
  <div class="cbox" id='user-login'>
    <p><?php echo T_("Login user and get new apikey for this user"); ?></p>
    <div class="msg url">
      <i class="method">POST</i>
      <span><?php echo \dash\data::CustomerApiURL(); ?><b>account/enter</b></span>
    </div>

    <div class="tblBox">
      <h3><?php echo T_("Required parameters"); ?> <?php echo T_("on header"); ?></h3>
      <table class="tbl1 v3">
        <thead>
          <tr>
            <th><?php echo T_("Name"); ?> <small><?php echo T_("type"); ?></small></th>
            <th><?php echo T_("Description"); ?> <small><?php echo T_("example"); ?></small></th>
            <th><?php echo T_("Constraints"); ?></th>
          </tr>
        </thead>
        <tbody>
           <tr>
            <td>
              <div class="txtB">appkey</div>
              <i>string</i>
            </td>
            <td>
              <div><?php echo T_("APP key generated on the user panel"); ?></div>
              <code><?php echo \dash\data::myAppKey(); ?></code>
            </td>
            <td>
              <div class="fc-red"><i><?php echo T_("Required"); ?></i></div>
              <?php echo T_("length"); ?> <?php echo \dash\fit::number(32); ?>
            </td>
          </tr>

          <tr>
            <td>
              <div class="txtB">token</div>
              <i>string</i>
            </td>
            <td>
              <div><?php echo T_("Your temporary token"); ?></div>
              <code>ec8e69c19ebb7c202ae1097aa40484e0</code>
            </td>
            <td>
              <div class="fc-red"><i><?php echo T_("Required"); ?></i></div>
              <?php echo T_("length"); ?> <?php echo \dash\fit::number(32); ?>
              <div><?php echo T_("To get this token see"); ?> <a href="<?php echo \dash\url::that(); ?>#token"><small><?php echo T_("Read more"); ?></small></a></div>
            </td>
          </tr>

          <tr>
            <td>
              <div class="txtB">apikey</div>
              <i>string</i>
            </td>
            <td>
              <div><?php echo T_("Your temporary apikey"); ?></div>
              <code>87923bd0d04b30aa5f66b699c2698e3b</code>
            </td>
            <td>
              <div class="fc-red"><i><?php echo T_("Required"); ?></i></div>
              <?php echo T_("length"); ?> <?php echo \dash\fit::number(32); ?>
              <div><?php echo T_("Get from your account or signup user"); ?> <a href="<?php echo \dash\url::that(); ?>#user-add"><small><?php echo T_("Read more"); ?></small></a></div>
          </td>
          </tr>
        </tbody>
      </table>
    </div>


    <div class="tblBox">
      <h3><?php echo T_("Required parameters"); ?></h3>
      <table class="tbl1 v3">
        <thead>
          <tr>
            <th><?php echo T_("Name"); ?> <small><?php echo T_("type"); ?></small></th>
            <th><?php echo T_("Description"); ?> <small><?php echo T_("example"); ?></small></th>
            <th><?php echo T_("Constraints"); ?></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <div class="txtB">mobile</div>
              <i>number</i>
            </td>
            <td>
              <div class="fc-mute"><?php echo T_("example"); ?></div>
              <code>989121234567</code>
            </td>
            <td>
              <div class="fc-red"><i><?php echo T_("Required"); ?></i></div>
              <?php echo T_("Max length"); ?> <?php echo \dash\fit::number(12); ?>
              <?php echo T_("Min length"); ?> <?php echo \dash\fit::number(7); ?>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <h3><?php echo T_("cURL"); ?> <small><?php echo T_("example"); ?></small></h3>
<pre>
curl -X POST \
  <?php echo \dash\data::CustomerApiURL(); ?>account/enter \
  -H 'appkey: <?php echo \dash\data::myAppKey(); ?>' \
  -H 'token: ec8e69c19ebb7c202ae1097aa40484e0' \
  -H 'apikey: <?php echo \dash\data::myApiKey(); ?>' \
  -d '{"mobile":"989121234567"}'
</pre>

    <h3><?php echo T_("Response"); ?> <small><?php echo T_("example"); ?></small></h3>
<pre>
{
  "ok": true,
  "msg": [
    {
      "type": "ok",
      "text": "The verification code sended to phone number"
    }
  ],
  "result": null
}
</pre>

  </div>
</div>

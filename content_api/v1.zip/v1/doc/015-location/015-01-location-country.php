<h2 class="f" data-kerkere='#location-country-detail' data-kerkere-icon='open'>
  <span class="cauto pRa10"><span class="badge success">GET</span></span>
  <span class="c"><?php echo T_("Get list of country"); ?></span>
</h2>
<div id="location-country-detail">
  <div class="cbox" id='location-country'>
    <p><?php echo T_("The endpoint for this method is different"); ?></p>
    <div class="msg url">
      <i class="method">GET</i>
      <span><?php echo \dash\data::JibresApiURL(); ?><b>location/country</b></span>
    </div>

    <h3><?php echo T_("cURL"); ?> <small><?php echo T_("example"); ?></small></h3>
<pre>curl -X GET <?php echo \dash\data::JibresApiURL(); ?>location/country</pre>

    <h3><?php echo T_("Response"); ?> <small><?php echo T_("example"); ?></small></h3>
<pre>
{
  "ok": true,
  "result": [
    {
      "id": 0,
      "text": "Please choose country",
      "disable": true
    },
    {
      "slug": "iran",
      "name": "iran",
      "localname": "‫ایران",
      "phonecode": 98,
      "language": "fa-IR",
      "containent": "Asia",
      "shortcontainent": "AS",
      "capital": "Tehran",
      "shortname": "IRR",
      "iso2": "IR",
      "iso3": "IRN",
      "width": "-",
      "length": "-",
      "id": "IR",
      "text": "‫ایران",
      "flag": "<?php echo \dash\url::site(); ?>/static/img/flags/png100px/ir.png"
    },
    ...
  ]
}
</pre>

  </div>
</div>

<?php
namespace content_i\category\home;

class controller
{

	public static function routing()
	{

	}
}
?>
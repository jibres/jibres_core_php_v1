<?php
namespace content_i\category\edit;


class controller
{
	public static function routing()
	{

	}
}
?>
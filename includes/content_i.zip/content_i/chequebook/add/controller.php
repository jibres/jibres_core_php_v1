<?php
namespace content_i\checkbook\add;

class controller
{

	public static function routing()
	{

	}
}
?>
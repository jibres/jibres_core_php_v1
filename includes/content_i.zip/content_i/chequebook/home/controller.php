<?php
namespace content_i\checkbook\home;

class controller
{

	public static function routing()
	{

	}
}
?>
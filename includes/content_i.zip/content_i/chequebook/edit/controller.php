<?php
namespace content_i\checkbook\edit;


class controller
{
	public static function routing()
	{

	}
}
?>
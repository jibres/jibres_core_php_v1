<?php
namespace content_i\bank\edit;


class controller
{
	public static function routing()
	{

	}
}
?>
<?php
namespace content_i\bank\home;

class controller
{

	public static function routing()
	{

	}
}
?>
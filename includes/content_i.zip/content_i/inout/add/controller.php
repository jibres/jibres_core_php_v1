<?php
namespace content_i\inout\add;

class controller
{

	public static function routing()
	{

	}
}
?>
<?php
namespace content_i\inout\home;

class controller
{

	public static function routing()
	{

	}
}
?>
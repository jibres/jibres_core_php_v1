<?php
namespace content_i\inout\edit;


class controller
{
	public static function routing()
	{

	}
}
?>
<?php
namespace content_i\check\home;

class controller
{

	public static function routing()
	{

	}
}
?>
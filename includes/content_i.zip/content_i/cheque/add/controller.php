<?php
namespace content_i\check\add;

class controller
{

	public static function routing()
	{

	}
}
?>
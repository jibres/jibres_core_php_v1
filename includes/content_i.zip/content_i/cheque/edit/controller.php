<?php
namespace content_i\check\edit;


class controller
{
	public static function routing()
	{

	}
}
?>
<?php
namespace content_i\home;

class controller
{

	public static function routing()
	{

	}
}
?>
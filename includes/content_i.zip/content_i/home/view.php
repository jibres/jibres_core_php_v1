<?php
namespace content_i\home;

class view
{
	public static function config()
	{

	}
}
?>
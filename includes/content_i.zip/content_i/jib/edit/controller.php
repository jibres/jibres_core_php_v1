<?php
namespace content_i\jib\edit;


class controller
{
	public static function routing()
	{

	}
}
?>
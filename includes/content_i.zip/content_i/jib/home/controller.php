<?php
namespace content_i\jib\home;

class controller
{

	public static function routing()
	{

	}
}
?>
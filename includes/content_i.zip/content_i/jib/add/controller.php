<?php
namespace content_i\jib\add;

class controller
{

	public static function routing()
	{

	}
}
?>
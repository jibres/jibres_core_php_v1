<?php
namespace content_subdomain\theme_full;


class view
{
	public static function config()
	{

	}
}
?>
<?php
namespace content_subdomain\theme_start;


class view
{
	public static function config()
	{

	}
}
?>